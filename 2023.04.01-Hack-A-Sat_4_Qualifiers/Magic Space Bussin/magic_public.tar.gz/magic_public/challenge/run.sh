#!/bin/bash

echo ${FLAG:=CONTACT_AN_ADMIN_IF_YOU_SEE_THIS} > flag.txt
cd /challenge
./magic
