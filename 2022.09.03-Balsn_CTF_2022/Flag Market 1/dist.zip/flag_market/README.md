# flag\_market

Run ./deploy.sh
