#!/bin/bash

echo $FLAG1
