#!/bin/sh
timeout --signal SIGKILL 60 ./main
