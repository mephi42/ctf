#!/bin/bash
timeout 10 cat | env -i /app/main