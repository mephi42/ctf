# RPG Game manual

## Rules

The rules are simple. Pick up all the keys on the map to get the flag. You lose if stepping on the bomb, trying to collect non-existing keys, or running out of time/steps.

The keys are hidden on the map. You can move around the map by `wasd` and collect the keys by `p`.

## Client-Server Communication

The hex data sent back by the server represents bytes data from SDP serialization results. **Below defines the SDP Struct of the data object:**

```py
@sdp_serializable
class Game:
    player = SdpField(0)
    name = SdpField(1)
    key_dists = SdpField(2)
    collected = SdpField(3)
```

- `player`: The player's position on the map.
- `name`: You will understand it as you interact with the server.
- `key_dists`: A list of Manhattan distances between the player and all uncollected keys, sorted in ascending order.
- `collected`: The number of keys you have collected.

You are expected to figure out their actual values and data types by yourself. `template.py` provides a good sanity check between your implementation of SDP and the server's.