# SDP (Simple Data Protocol) Serialization Specification

## 1. Overview

SDP is a compact binary serialization format designed for efficient data transmission and storage. It supports various data types and nested structures, making it suitable for complex data representations.

## 2. Data Types

SDP supports the following data types, represented by their corresponding enum values in the header:

| Enum Value | Data Type        | Description                                    |
|------------|------------------|------------------------------------------------|
| 0          | Integer_Positive | Positive integer (0 to 2^28 - 1)               |
| 1          | Integer_Negative | Negative integer (-1 to -2^28)                 |
| 2          | Float            | 32-bit IEEE 754 single-precision floating-point|
| 3          | Double           | 64-bit IEEE 754 double-precision floating-point|
| 4          | String           | UTF-8 encoded string                           |
| 5          | Vector           | List of elements (any type)                    |
| 6          | Map              | Key-value pairs (any types)                    |
| 7          | StructBegin      | Marker for the beginning of a nested structure |
| 8          | StructEnd        | Marker for the end of a nested structure       |

## 3. Packet Structure

Each data element in SDP is represented as a packet with the following structure:

```
[Header (1 byte)] [Extended Tag (optional)] [Value]
```

### 3.1 Header

The header is a single byte composed of two parts:
- Type (4 bits): Represents the data type (0-8)
- Tag (4 bits): Uniquely identifies the packet field (0-15)

If the tag value is 15, an extended tag follows the header.

### 3.2 Extended Tag

When the tag in the header is 15, the actual tag value follows as a variable-length integer.

### 3.3 Value

The value format depends on the data type:

1. Integer (Positive/Negative): Variable-length encoding
2. Float: 4 bytes (IEEE 754 single-precision)
3. Double: 8 bytes (IEEE 754 double-precision)
4. String: Length (variable-length integer) followed by UTF-8 encoded bytes
5. Vector: Length (variable-length integer) followed by serialized elements
6. Map: Length (variable-length integer) followed by serialized key-value pairs
7. Struct: Serialized fields between StructBegin and StructEnd markers

## 4. Encoding Details

### 4.1 Variable-length Integer Encoding

Integers are encoded using a variable-length scheme:
- Each byte uses 7 bits for the value and 1 bit to indicate if more bytes follow
- The value is reconstructed by concatenating the 7-bit segments
- For negative integers, the absolute value is encoded, and the sign is indicated by the type in the header

### 4.2 Floating-Point Encoding

- Float: Encoded as 4 bytes using IEEE 754 single-precision format
- Double: Encoded as 8 bytes using IEEE 754 double-precision format

### 4.3 String Encoding

Strings are encoded as:
1. Length of the string (variable-length integer)
2. UTF-8 encoded bytes of the string

### 4.4 Vector Encoding

Vectors are encoded as:
1. Number of elements (variable-length integer)
2. Serialized elements, each with its own header and value
Note that the tags for elements are always 0.

### 4.5 Map Encoding

Maps are encoded as:
1. Number of key-value pairs (variable-length integer)
2. Serialized key-value pairs, each key and value with its own header and value
Note that the tags for key-value pairs are always 0.

### 4.6 Struct Encoding

Structs are encoded as follows:
1. StructBegin marker (type 7 in header)
2. Serialized fields (each with its own header and value)
3. StructEnd marker (type 8 in header)

## 5. Decoding Process

1. Read the header byte
2. Determine the type and tag
3. If tag is 15, read the extended tag
4. Based on the type, read and interpret the value:
   - For integers, read variable-length encoding
   - For floats and doubles, read 4 or 8 bytes respectively
   - For strings, read length then UTF-8 bytes
   - For vectors and maps, read count then decode elements
   - For structs, decode fields until StructEnd is encountered
5. For structs, vectors, and maps, recursively decode nested elements

## 6. Error Handling

Implementations should handle the following error conditions:
- Invalid type in header (outside 0-8 range)
- Unexpected end of data
- Invalid length for strings, vectors, or maps
- Mismatched StructBegin and StructEnd markers
- Invalid IEEE 754 representations for floats and doubles

## 7. Best Practices

1. Use consistent tag number for the same field across versions of a struct
2. Consider byte order (endianness) when implementing on different platforms
3. Implement version checking if backward compatibility is required
4. Use appropriate data types to minimize serialized data size
5. For floating-point values, be aware of potential precision loss when using Float instead of Double

## 8. Limitations

- Maximum of 2^28 - 1 fields per struct (due to 4-bit tag + extended tag)
- No built-in support for binary data (use base64 encoding with strings if needed)
- No Schema Definition Language (SDL) provided (consider documenting structures separately)
- Limited to IEEE 754 floating-point representations