'''
`sdp` is the library for SDP (Simple Data Protocol) Serialization and Deserialization.
This file serves as a reference for the output of packing and unpacking an SDP-serializable object.
'''
from sdp import sdp_serializable, SdpField, SdpStruct
from typing import Dict

@sdp_serializable
class Example:
    name = SdpField(0) # name is a String with tag 0
    age = SdpField(1) # age is an Integer_Positive with tag 1
    grades = SdpField(2) # grades is a Map with tag 2

    def __init__(self, name: str, age: int, grades: Dict[str, int]):
        self.name = name
        self.age = age
        self.grades = grades

if __name__ == "__main__":
    example = Example(
        name="Alice",
        age=20,
        grades={"Math": 90, "Physics": 85, "Chemistry": 0})

    sdp_struct = SdpStruct(example.__sdp_serialize__())
    packed_data = sdp_struct.pack()
    unpacked_data = SdpStruct.unpack(packed_data)
    assert unpacked_data[0] == "Alice"

    print(f"Original: {example.__sdp_serialize__()}")
    print(f"Packed: {packed_data}")
    print(f"Unpacked: {unpacked_data}")

    # Test updating the name
    example.name = "Bob"
    packed_data = SdpStruct(example.__sdp_serialize__()).pack()
    unpacked_data = SdpStruct.unpack(packed_data)
    assert unpacked_data[0] == "Bob"

'''
Original: {1: 20, 2: {'Math': 90, 'Physics': 85, 'Chemistry': 0}, 0: 'Alice'}
Packed: b'p@\x05Alice\x01\x14b\x03@\x04Math\x00Z@\x07Physics\x00U@\tChemistry\x00\x00\x80'
Unpacked: {0: 'Alice', 1: 20, 2: {'Math': 90, 'Physics': 85, 'Chemistry': 0}}
'''