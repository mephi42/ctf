#!/bin/sh
./lib/ld-2.31.so --library-path ./lib ./bin/chall
