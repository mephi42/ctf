#!/bin/sh
docker build -t pbctf-qemu .
