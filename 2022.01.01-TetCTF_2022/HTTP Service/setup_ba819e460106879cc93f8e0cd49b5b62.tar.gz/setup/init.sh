#!/bin/sh
#

service lighttpd start && sleep infinity