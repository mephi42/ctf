// gcc main.c -o main -z relro -z now -z execstack -fstack-protector -lseccomp
// Patch call rdx ==> jmp rdx

#include <stdio.h>
#include <seccomp.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

char *p;

void goDark(){
    scmp_filter_ctx ctx = seccomp_init(SECCOMP_RET_ALLOW);

    for(int i=1; i<329; i++)
        if(i != 60 && i != 231 && i != 3) seccomp_rule_add(ctx, SECCOMP_RET_KILL, i, 0);

	seccomp_load(ctx);
	seccomp_release(ctx);

    fclose(stdout);
    fclose(stderr);
}

int main(int argc, char *argv[], char *envp[]){
    assert(getenv("FLAG") != NULL);
    assert(strstr(getenv("FLAG"), "Securinets{") == getenv("FLAG"));

    char code[14] = "H1\xd2";
    goDark();

    read(0, code+3, sizeof(code)-3);
    p = code;
    __asm__("xor %rax, %rax\n"
            "xor %rsi, %rsi\n"
            "xor %rsp, %rsp\n"
            "xor %rbx, %rbx\n"
            "xor %rbp, %rbp\n"
            "xor %rcx, %rcx\n"
            "xor %rdx, %rdx\n"
            "xor %rdi, %rdi\n"
            "xor %r8, %r8\n"
            "xor %r9, %r9\n"
            "xor %r10, %r10\n"
            "xor %r11, %r11\n"
            "xor %r12, %r12\n"
            "xor %r13, %r13\n"
            "xor %r14, %r14\n"
            "xor %r15, %r15\n");

    ((void (*)())p)();
    return 0;
}
