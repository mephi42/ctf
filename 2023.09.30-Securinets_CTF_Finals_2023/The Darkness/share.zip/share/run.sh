#! /bin/bash

timeout 5 cat | env -i REDACTED_COUNT1=REDACTED REDACTED_COUNT2=REDACTED REDACTED_COUNT3=REDACTED FLAG="Securinets{REDACTED}" REDACTED_COUNT4=REDACTED ./main2

# The number & order of env variables is not given.

