#!/bin/bash

python3.10 main.py
