#!/usr/local/bin/python3.10
import sys
import dis


print("Define a function called f to be called at the end of execution.")
print("Example of definition:")
print("def f(): pass")
print("Send an empty line when you're done.")
print("PS: Flag name is random so, you need a shell.")

code = ""
while True:
    line = input("> ")
    if line == "":
        break
    code += "\n" + line


# Sorry
blacklist = [
    "subprocess",
    "os",
    "code",
    "interact",
    "pty",
    "pdb",
    "platform",
    "importlib",
    "timeit",

    "popen",
    "load_module",
    "spawn",
    
    "/bin/sh",
    "/bin/bash",
    
    "flag",
    "read",
    "open",
    "eval",
    "input",
    "vars",
    "attr",
    "dir",
    "getattr"
    
    "__import__",
    "__builtins__",
    "__getattribute__",
    "__getitem__",
    "__self__",
    "__globals__",
    "__init__",
    "__name__",
    "__dict__",
    "._module",
    "builtins",
    "breakpoint",
    
    "import ",
]
whitelist = list('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~ \t\n\r')

for w in blacklist:
    if w in code:
        print(w)
        print("no")
        exit()

for c in code:
    if c not in whitelist:
        print("no")
        exit()

compiled = compile(code, "", "single")
bcode = dis.Bytecode(code)
allowedOpCodes = [
    "LOAD_CONST",
    "MAKE_FUNCTION",
    "STORE_NAME",
    "RETURN_VALUE",
]

for opcode in bcode:
    if opcode.opname not in allowedOpCodes:
        print(opcode)
        print("wot u doin?")
        exit()

if compiled.co_consts[0].__class__.__name__ != 'code':
    print("no")
    exit()

fnCode = compiled.co_consts[0]
blacklist += ["imp", "exec",] # more stuff
for w in blacklist:
    if w in fnCode.co_names or w in fnCode.co_consts:
        print("no")
        exit()


badopcode = ['IMPORT_NAME', 'IMPORT_STAR', 'IMPORT_FROM']
for opcode in dis.Bytecode(fnCode):
    if opcode.opname in badopcode:
        print("no")
        exit()


def f(): pass
exec(code)

class A: 
    def __del__(self):
        f()

a = A()

del code
del blacklist
del badopcode
del fnCode
del compiled
del allowedOpCodes
del dis
del bcode

__builtins__.__dict__.clear()
__builtins__ = None


