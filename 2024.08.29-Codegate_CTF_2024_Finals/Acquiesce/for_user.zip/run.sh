#!/bin/bash
timeout 30 /home/acquiesce/acquiesce