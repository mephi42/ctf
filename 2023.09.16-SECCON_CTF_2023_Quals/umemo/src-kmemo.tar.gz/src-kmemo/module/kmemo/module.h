#ifndef _KMEMO_MODULE_H
#define _KMEMO_MODULE_H

#define MODULE_NAME "tmp-memo"

#endif
