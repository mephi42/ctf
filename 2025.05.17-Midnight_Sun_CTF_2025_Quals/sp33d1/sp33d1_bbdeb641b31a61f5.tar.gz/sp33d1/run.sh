#!/bin/bash
qemu-ppc ./sp33d1
